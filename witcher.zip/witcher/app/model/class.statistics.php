<?php
namespace Model;

class statistics{

}