<?php
namespace Config;

class database{
    public $db_name = "bookstore"; // MAIN Database name bmbgames_demo
    public $db_username = "root"; // MAIN Database Username bmbgames_demo
    public $db_password = ""; // MAIN Database Password N70isbest
    public $db_host = "localhost"; // MAIN Host name
    public $db_charset = "utf8"; // charset ( dont change )
}