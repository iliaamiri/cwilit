<?php
namespace Config;

class server{
    public $INFO = [
        'Port' => 'http',
        'Domain' => 'bmbgames.com',
        'IpServer' => '127.0.0.1'
    ];
}